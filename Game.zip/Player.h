#ifndef PLAYER_H
#define PLAYER_H

#include <QGraphicsPixmapItem>
#include <QKeyEvent>
#include <QObject>
#include <QMessageBox>
#include <QAudioOutput>
#include <QMediaPlayer>

class Player : public QObject, public QGraphicsPixmapItem {
    Q_OBJECT
public:
    Player(int x, int y, int w, int h);

    void decreaseHealth();
    void increaseScore();

    int getHealth();
    int getScore();

    void playEnemyDestroyedSound();


protected:
    void keyPressEvent(QKeyEvent *event);

private:
    int health;
    int score;
    QMediaPlayer *bulletSoundPlayer;
    QAudioOutput *bulletSoundAudioOutput;
    QMediaPlayer *enemyDestroyedPlayer;
    QAudioOutput *enemyDestroyedAudioOutput;
};

#endif // PLAYER_H
