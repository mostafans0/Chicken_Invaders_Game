#include <QApplication>
#include "Game.h"
#include "qgraphicsview.h"

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);

    Game game;
    game.setSceneRect(0, 0, 800, 600);
    game.setItemIndexMethod(QGraphicsScene::NoIndex);
    game.setBackgroundBrush(QBrush(Qt::white));

    QGraphicsView view(&game);
    view.setRenderHint(QPainter::Antialiasing);
    view.setBackgroundBrush(QBrush(Qt::white));
    view.setCacheMode(QGraphicsView::CacheBackground);
    view.setViewportUpdateMode(QGraphicsView::BoundingRectViewportUpdate);
    view.setDragMode(QGraphicsView::ScrollHandDrag);
    view.setWindowTitle("Space Invaders");
    view.setFixedSize(800, 600);
    view.show();

    return a.exec();
}
