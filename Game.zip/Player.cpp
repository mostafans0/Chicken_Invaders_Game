#include "Player.h"
#include "Bullet.h"
#include "qgraphicsscene.h"
#include <QPixmap>
#include <QKeyEvent>
#include <QDebug>
#include <QMessageBox>
#include <QAudioOutput>
#include <QMediaPlayer>



Player::Player(int x, int y, int w, int h)
    : health(3), score(0)
{
    QPixmap playerPixmap(":/SpaceShip.png2.png");
    setPixmap(playerPixmap.scaled(w, h));
    setPos(x, y);

    setFlag(QGraphicsItem::ItemIsFocusable);
    setFocus();

    qDebug() << "Player initialized.";

    bulletSoundPlayer = new QMediaPlayer(this);
    bulletSoundAudioOutput = new QAudioOutput(this);
    bulletSoundPlayer->setAudioOutput(bulletSoundAudioOutput);
    bulletSoundAudioOutput->setVolume(100);

    enemyDestroyedPlayer = new QMediaPlayer(this);
    enemyDestroyedAudioOutput = new QAudioOutput(this);
    enemyDestroyedPlayer->setAudioOutput(enemyDestroyedAudioOutput);
    enemyDestroyedAudioOutput->setVolume(100);

}



void Player::keyPressEvent(QKeyEvent *event) {
    int stepSize = 15;

    if (event->key() == Qt::Key_Right) {
        if (x() + pixmap().width() < scene()->width())
            setPos(x() + stepSize, y());
    } else if (event->key() == Qt::Key_Left) {
        if (x() > 0)
            setPos(x() - stepSize, y());
    } else if (event->key() == Qt::Key_Space) {
        Bullet *bullet = new Bullet(x() + pixmap().width() / 2, y() - 50, 10, 30);
        scene()->addItem(bullet);

        bulletSoundPlayer->setSource(QUrl::fromLocalFile(":/BulletSound.mp3"));
        bulletSoundPlayer->play();

    }
}


void Player::increaseScore() {
    score++;
}

void Player::decreaseHealth(){
    health--;
}

int Player::getHealth() {
    return health;
}

int Player::getScore() {
    return score;
}

void Player::playEnemyDestroyedSound() {
    qDebug() << "Playing enemy destroyed sound!";
    enemyDestroyedPlayer->setSource(QUrl::fromLocalFile(":/Voicy_Minecraft Chicken Death Sound.mp3"));
    enemyDestroyedPlayer->play();
}
