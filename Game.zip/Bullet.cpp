#include "Bullet.h"
#include "Enemy.h"
#include "Player.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QDebug>
#include <QApplication>
#include <QAudioOutput>
#include <QMediaPlayer>



Bullet::Bullet(int x, int y, int w, int h) {

    QPixmap bulletPixmap(":/Bullet.Png");
    setPixmap(bulletPixmap.scaled(w, h));
    setPos(x, y);

    QTimer *t = new QTimer(this);
    connect(t, SIGNAL(timeout()), this, SLOT(move()));
    t->start(50);
}

void Bullet::move() {
    Player *player = dynamic_cast<Player *>(scene()->focusItem());
    QList<QGraphicsItem *> collidingEnemies = collidingItems();
    for (QGraphicsItem *c : collidingEnemies) {
        if (typeid(*c) == typeid(Enemy)) {
            scene()->removeItem(c);
            scene()->removeItem(this);
            delete c;
            delete this;
            player->increaseScore();
            qDebug() << "Bullet hit an enemy and deleted.";

            player->playEnemyDestroyedSound();

            return;

        }
    }
    setPos(x(), y() - 15);
    if (y() + pixmap().height() < 0) {
        scene()->removeItem(this);
        delete this;
        qDebug() << "Bullet deleted when leaving scene.";
    }
}
