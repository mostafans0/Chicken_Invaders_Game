#ifndef GAME_H
#define GAME_H

#include <QGraphicsScene>
#include <QTimer>
#include "Player.h"
#include <QApplication>



class Game : public QGraphicsScene {
    Q_OBJECT
public:
    Game();

private slots:
    void createEnemy();

private:
    QTimer *enemyCreatorTimer;
    Player *player;
};

#endif // GAME_H
