#include "Game.h"
#include "Bullet.h"
#include "Enemy.h"
#include <QRandomGenerator>
#include <QMessageBox>


Game::Game() {
    setSceneRect(0, 0, 800, 600);

    player = new Player(0, 0, 100, 100);
    player->setPixmap(QPixmap(":/SpaceShip.png2.png").scaled(100, 100));
    player->setPos((width() / 2) - 50, height() - player->pixmap().height());
    addItem(player);

    enemyCreatorTimer = new QTimer(this);
    enemyCreatorTimer->start(1000);
    connect(enemyCreatorTimer, SIGNAL(timeout()), this, SLOT(createEnemy()));


    qDebug() << "Game initialized.";
}

void Game::createEnemy() {
    Enemy *enemy = new Enemy();
    enemy->setPos(QRandomGenerator::global()->bounded(700), 0);
    addItem(enemy);

    qDebug() << "Enemy created at" << enemy->pos().x() << "," << enemy->pos().y();
}
