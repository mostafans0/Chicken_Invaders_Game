#include "Enemy.h"
#include "Player.h"
#include "qapplication.h"
#include <QTimer>
#include <QGraphicsScene>
#include <QRandomGenerator>
#include <QDebug>
#include <QApplication>


Enemy::Enemy() {
    QPixmap enemyPixmap(":/Enemy.Png");
    setPixmap(enemyPixmap.scaled(50, 50));
    setPos(QRandomGenerator::global()->bounded(700), 0);

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(move()));
    timer->start(100);
}

void Enemy::move() {
    setPos(x(), y() + 10);
Player *player = dynamic_cast<Player *>(scene()->focusItem());
    if (y() > scene()->height()) {
        // If enemy leaves the scene
        scene()->removeItem(this);
        delete this;
        qDebug() << "Enemy deleted when leaving scene.";
        player->decreaseHealth();

        if (player->getHealth() < 1) {
            QMessageBox *msg = new QMessageBox;
            msg->setWindowTitle("Game Over");
            msg->setText("Game Over! You lose.\nScore: " + QString::number(player->getScore()));
            msg->exec();
            qApp->quit();
    }
}
}
